﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Hang : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        else if (Session["userLogin1"].ToString() != "QL")
        {
            Response.Redirect("HoaDon.aspx");
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
            Load_DSHang();
        }
        
    }
    private void Load_DSHang()
    {
        SqlDS.SelectCommand = "SELECT * FROM HANG";
        this.grv_hang.DataSource = SqlDS;
        this.grv_hang.DataBind();
    }
    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM HANG WHERE TenHang LIKE '%' + @TenHang + '%'";
        SqlDS.SelectParameters.Add("TenHang", TypeCode.String, this.txt_timkiem.Text);

        this.grv_hang.DataSource = SqlDS;
        this.grv_hang.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO HANG (MaHang,TenHang,DonGiaN) VALUES (@MaHang,@TenHang,@DonGiaN)";

        SqlDS.InsertParameters.Add("MaHang", TypeCode.String, this.txt_mahang.Text);
        SqlDS.InsertParameters.Add("TenHang", TypeCode.String, this.txt_tenhang.Text);
        SqlDS.InsertParameters.Add("DonGiaN", TypeCode.Int32, this.txt_dongia.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSHang();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE HANG SET TenHang = @TenHang, DonGiaN = @DonGiaN WHERE MaHang = @MaHang";

        SqlDS.UpdateParameters.Add("MaHang", TypeCode.String, this.txt_mahang.Text);
        SqlDS.UpdateParameters.Add("TenHang", TypeCode.String, this.txt_tenhang.Text);
        SqlDS.UpdateParameters.Add("DonGiaN", TypeCode.Int32, this.txt_dongia.Text);

        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSHang();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.DeleteCommand = "DELETE FROM HANG WHERE MaHang = @MaHang";

        SqlDS.DeleteParameters.Add("MaHang", TypeCode.String, this.txt_mahang.Text);

        SqlDS.Delete();

        this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

        Load_DSHang();
    }
}