﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NhaCungCap : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        else if (Session["userLogin1"].ToString() != "QL")
        {
            Response.Redirect("HoaDon.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSNCC();
    }
    private void Load_DSNCC()
    {
        SqlDS.SelectCommand = "SELECT * FROM NHACUNGCAP";
        this.grv_ncc.DataSource = SqlDS;
        this.grv_ncc.DataBind();
    }
    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM NHACUNGCAP WHERE TenNCC LIKE '%' + @TenNCC + '%'";
        SqlDS.SelectParameters.Add("TenNCC", TypeCode.String, this.txt_timkiem.Text);

        this.grv_ncc.DataSource = SqlDS;
        this.grv_ncc.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO NHACUNGCAP (MaNCC,TenNCC, SDT, DChiNCC, STK) VALUES (@MaNCC, @TenNCC, @SDT, @DChiNCC, @STK)";

        SqlDS.InsertParameters.Add("MaNCC", TypeCode.String, this.txt_mancc.Text);
        SqlDS.InsertParameters.Add("TenNCC", TypeCode.String, this.txt_tenncc.Text);
        SqlDS.InsertParameters.Add("SDT", TypeCode.String, this.txt_sdt.Text);
        SqlDS.InsertParameters.Add("DChiNCC", TypeCode.String, this.txt_diachi.Text);
        SqlDS.InsertParameters.Add("STK", TypeCode.String, this.txt_stk.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSNCC();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE NHACUNGCAP SET TenNCC = @TenNCC, SDT = @SDT, DChiNCC = @DChiNCC, STK = @STK WHERE MaNCC = @MaNCC";

        SqlDS.UpdateParameters.Add("MaNCC", TypeCode.String, this.txt_mancc.Text);
        SqlDS.UpdateParameters.Add("TenNCC", TypeCode.String, this.txt_tenncc.Text);
        SqlDS.UpdateParameters.Add("SDT", TypeCode.String, this.txt_sdt.Text);
        SqlDS.UpdateParameters.Add("DChiNCC", TypeCode.String, this.txt_diachi.Text);
        SqlDS.UpdateParameters.Add("STK", TypeCode.String, this.txt_stk.Text);

        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSNCC();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.DeleteCommand = "DELETE FROM NHACUNGCAP WHERE MaNCC = @MaNCC";

        SqlDS.DeleteParameters.Add("MaNCC", TypeCode.String, this.txt_mancc.Text);

        SqlDS.Delete();

        this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

        Load_DSNCC();
    }
}