﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_dangnhap_Click(object sender, EventArgs e)
    {

        SqlConnection Sqlcon = new SqlConnection("Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True");

        SqlCommand cmd = new SqlCommand("SELECT * FROM TAIKHOAN WHERE TenDangNhap=@TenDangNhap and MatKhau=@MatKhau", Sqlcon);

        cmd.Parameters.AddWithValue("@TenDangNhap", txt_user.Text);
        cmd.Parameters.AddWithValue("@MatKhau", txt_password.Text);


        SqlDataSource SqlDS = new SqlDataSource();
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        SqlDS.SelectCommand = "SELECT LoaiNV FROM NHANVIEN,TAIKHOAN WHERE TAIKHOAN.MaNV = NHANVIEN.MaNV AND TenDangNhap = @TenDangNhap";
        SqlDS.SelectParameters.Add("TenDangNhap",TypeCode.String,this.txt_user.Text);

        DataView dv = (DataView)SqlDS.Select(DataSourceSelectArguments.Empty);
        if (dv.Count > 0)
        {
            string chucvu = Convert.ToString(dv.Table.Rows[0]["LoaiNV"]);
            Session["userLogin1"] = chucvu;
            Response.Redirect("Menu.aspx");
        }
        else
        {
            this.lbl_thongbao.Text = "Sai tài khoản hoặc mật khẩu !!!";
        }


      
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        Sqlcon.Open();
        int i = cmd.ExecuteNonQuery();
        Sqlcon.Close();

       

        
    }
}