﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Menu : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSMon();
    }

    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM MON WHERE TenMon LIKE '%' + @TenMon + '%'";
        SqlDS.SelectParameters.Add("TenMon",TypeCode.String,this.txt_timkiem.Text);

        this.grv_mon.DataSource = SqlDS;
        this.grv_mon.DataBind();
    }
    private void Load_DSMon()
    {
        SqlDS.SelectCommand = "SELECT * FROM MON";
        this.grv_mon.DataSource = SqlDS;
        this.grv_mon.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.InsertCommand = "INSERT INTO MON (MaMon,TenMon,DonGiaB) VALUES (@MaMon,@TenMon,@DonGiaB)";

            SqlDS.InsertParameters.Add("MaMon", TypeCode.String, this.txt_mamon.Text);
            SqlDS.InsertParameters.Add("TenMon", TypeCode.String, this.txt_tenmon.Text);
            SqlDS.InsertParameters.Add("DonGiaB", TypeCode.Int32, this.txt_dongia.Text);

            SqlDS.Insert();

            this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
            Load_DSMon();
        }    
    }
    protected void imgbtn_capnhat_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.UpdateCommand = "UPDATE MON SET TenMon = @TenMon, DonGiaB = @DonGiaB WHERE MaMon = @MaMon";

            SqlDS.UpdateParameters.Add("TenMon", TypeCode.String, this.txt_tenmon.Text);
            SqlDS.UpdateParameters.Add("DonGiaB", TypeCode.Int32, this.txt_dongia.Text);
            SqlDS.UpdateParameters.Add("MaMon", TypeCode.String, this.txt_mamon.Text);

            SqlDS.Update();
            this.lbl_thongbao.Text = "Đã cập nhật dữ liệu";

            Load_DSMon();
        }
        
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.DeleteCommand = "DELETE FROM MON WHERE MaMon = @MaMon";

            SqlDS.DeleteParameters.Add("MaMon", TypeCode.String, this.txt_mamon.Text);

            SqlDS.Delete();

            this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

            Load_DSMon();
        }       
    }
}