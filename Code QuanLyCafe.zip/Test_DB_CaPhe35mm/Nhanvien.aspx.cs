﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Nhanvien : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        else if (Session["userLogin1"].ToString() != "QL")
        {
            Response.Redirect("HoaDon.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSNhanvien();
    }

    private void Load_DSNhanvien()
    {
        SqlDS.SelectCommand = "SELECT * FROM NHANVIEN";
        this.grv_nhanvien.DataSource = SqlDS;
        this.grv_nhanvien.DataBind();
    }
    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM NHANVIEN WHERE TENNV LIKE '%' + @TENNV + '%'";
        SqlDS.SelectParameters.Add("TENNV", TypeCode.String, this.txt_timkiem.Text);

        this.grv_nhanvien.DataSource = SqlDS;
        this.grv_nhanvien.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO NHANVIEN (MaNV,TENNV,SDT,LoaiNV) VALUES (dbo.fMaNVNew(),@TENNV,@SDT,@LoaiNV)";

        SqlDS.InsertParameters.Add("TENNV", TypeCode.String, this.txt_tennv.Text);
        SqlDS.InsertParameters.Add("SDT", TypeCode.String, this.txt_sdt.Text);
        SqlDS.InsertParameters.Add("LoaiNV", TypeCode.String, this.ddl_chucvu.SelectedItem.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSNhanvien();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE NHANVIEN SET TENNV = @TENNV, SDT = @SDT, LoaiNV = @LoaiNV WHERE MaNV = @MaNV";

        SqlDS.UpdateParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.UpdateParameters.Add("TENNV", TypeCode.String, this.txt_tennv.Text);
        SqlDS.UpdateParameters.Add("SDT", TypeCode.String, this.txt_sdt.Text);
        SqlDS.UpdateParameters.Add("LoaiNV", TypeCode.String, this.ddl_chucvu.SelectedItem.Text);

        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSNhanvien();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.DeleteCommand = "DELETE FROM NHANVIEN WHERE MaNV = @MaNV";

        SqlDS.DeleteParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);

        SqlDS.Delete();

        this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

        Load_DSNhanvien();
    }
}