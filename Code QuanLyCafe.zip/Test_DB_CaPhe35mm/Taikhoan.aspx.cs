﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Taikhoan : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        else if (Session["userLogin1"].ToString() != "QL")
        {
            Response.Redirect("HoaDon.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSTaikhoan();
    }

    private void Load_DSTaikhoan()
    {
        SqlDS.SelectCommand = "SELECT * FROM TAIKHOAN";
        this.grv_taikhoan.DataSource = SqlDS;
        this.grv_taikhoan.DataBind();
    }
    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM TAIKHOAN WHERE TenDangNhap LIKE '%' + @TenDangNhap + '%'";
        SqlDS.SelectParameters.Add("TenDangNhap", TypeCode.String, this.txt_timkiem.Text);

        this.grv_taikhoan.DataSource = SqlDS;
        this.grv_taikhoan.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO TAIKHOAN (MaTK,MaNV,TenDangNhap,MatKhau) VALUES (@MaTK,@MANV,@TenDangNhap,@MatKhau)";

        SqlDS.InsertParameters.Add("MaTK", TypeCode.String, this.txt_matk.Text);
        SqlDS.InsertParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.InsertParameters.Add("TenDangNhap", TypeCode.String, this.txt_tendangnhap.Text);
        SqlDS.InsertParameters.Add("MatKhau", TypeCode.String, this.txt_matkhau.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSTaikhoan();
    }
    protected void imgbtn_capnhat_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE TAIKHOAN SET TenDangNhap = @TenDangNhap, MatKhau = @MatKhau WHERE MaTK = @MaTK AND MaNV = @MaNV";

        SqlDS.UpdateParameters.Add("MaTK", TypeCode.String, this.txt_matk.Text);
        SqlDS.UpdateParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.UpdateParameters.Add("TenDangNhap", TypeCode.String, this.txt_tendangnhap.Text);
        SqlDS.UpdateParameters.Add("MatKhau", TypeCode.String, this.txt_matkhau.Text);

        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSTaikhoan();
    }


    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.DeleteCommand = "DELETE FROM TAIKHOAN WHERE MaTK = @MaTK";

        SqlDS.DeleteParameters.Add("MaTK", TypeCode.String, this.txt_matk.Text);

        SqlDS.Delete();

        this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

        Load_DSTaikhoan();
    }
}