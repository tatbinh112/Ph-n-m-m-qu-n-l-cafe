﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HoaDon : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSHoadon();
    }
    private void Load_DSHoadon()
    {
        SqlDS.SelectCommand = "SELECT * FROM THANHTOAN";
        this.grv_hoadon.DataSource = SqlDS;
        this.grv_hoadon.DataBind();
    }
    protected void btn_timkiem_Click(object sender, EventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.SelectCommand = "SELECT * FROM THANHTOAN WHERE MaHD LIKE '%' + @MaHD + '%'";
        SqlDS.SelectParameters.Add("MaHD", TypeCode.String, this.txt_timkiem.Text);

        this.grv_hoadon.DataSource = SqlDS;
        this.grv_hoadon.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO THANHTOAN (MaHD,NgayTT,GioVao,GioRa,ChietKhau,MaNV,SoBan) VALUES (dbo.fMahd(),GETDATE(),@GioVao,CONVERT(varchar, GETDATE(), 108),@ChietKhau,@MaNV,@SoBan)";

        SqlDS.InsertParameters.Add("GioVao", TypeCode.String, this.txt_gio.Text);
        SqlDS.InsertParameters.Add("ChietKhau", TypeCode.String, this.txt_chietkhau.Text);
        SqlDS.InsertParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.InsertParameters.Add("SoBan", TypeCode.String, this.txt_ban.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSHoadon();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE THANHTOAN SET MaNV = @MaNV, SoBan = @SoBan, ChietKhau = @ChietKhau WHERE MaHD = @MaHD";

        SqlDS.UpdateParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.UpdateParameters.Add("SoBan", TypeCode.String, this.txt_ban.Text);
        SqlDS.UpdateParameters.Add("ChietKhau", TypeCode.String, this.txt_chietkhau.Text);
        SqlDS.UpdateParameters.Add("MaHD", TypeCode.String, this.txt_mahoadon.Text);

        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSHoadon();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.DeleteCommand = "DELETE FROM THANHTOAN WHERE MaHD = @MaHD";

            SqlDS.DeleteParameters.Add("MaHD", TypeCode.String, this.txt_mahoadon.Text);

            SqlDS.Delete();

            this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

            Load_DSHoadon();
        } 
    }
}