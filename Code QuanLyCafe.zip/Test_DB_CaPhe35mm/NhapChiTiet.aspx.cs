﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NhapChiTiet : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSNhaphang();
    }
    private void Load_DSNhaphang()
    {
        SqlDS.SelectCommand = "SELECT * FROM NHAPCHITIET";
        this.grv_nhaphang.DataSource = SqlDS;
        this.grv_nhaphang.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO NHAPCHITIET (MaDNH,MaHang,SoLuong) VALUES (@MaDNH,@MaHang,@SoLuong)";

        SqlDS.InsertParameters.Add("MaDNH", TypeCode.String, this.txt_madnh.Text);
        SqlDS.InsertParameters.Add("MaHang", TypeCode.String, this.txt_mahang.Text);
        SqlDS.InsertParameters.Add("SoLuong", TypeCode.String, this.txt_soluong.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSNhaphang();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE NHAPCHITIET SET MaHang = @MaHang, SoLuong = @SoLuong WHERE MaDNH = @MaDNH";

        SqlDS.UpdateParameters.Add("MaHang", TypeCode.String, this.txt_mahang.Text);
        SqlDS.UpdateParameters.Add("SoLuong", TypeCode.String, this.txt_soluong.Text);
        SqlDS.UpdateParameters.Add("MADNH", TypeCode.String, this.txt_madnh.Text);


        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSNhaphang();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.DeleteCommand = "DELETE FROM NHAPCHITIET WHERE MaDNH = @MaDNH";

            SqlDS.DeleteParameters.Add("MaDNH", TypeCode.String, this.txt_madnh.Text);

            SqlDS.Delete();

            this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

            Load_DSNhaphang();
        }   
    }
}