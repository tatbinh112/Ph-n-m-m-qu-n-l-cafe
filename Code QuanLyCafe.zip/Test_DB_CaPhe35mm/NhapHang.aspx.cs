﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NhapHang : System.Web.UI.Page
{
    SqlDataSource SqlDS = new SqlDataSource();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userLogin1"].ToString() == "")
        {
            Response.Redirect("Login.aspx");
        }
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";
        Load_DSNhaphang();
    }
    private void Load_DSNhaphang()
    {
        SqlDS.SelectCommand = "SELECT * FROM NHAP";
        this.grv_nhaphang.DataSource = SqlDS;
        this.grv_nhaphang.DataBind();
    }
    protected void imgbtn_them_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.InsertCommand = "INSERT INTO NHAP (MaDNH,NgayNH,MaNCC,MaNV) VALUES (dbo.fMadnh(),GETDATE(),@MaNCC,@MaNV)";

        SqlDS.InsertParameters.Add("MaNCC", TypeCode.String, this.txt_mancc.Text);
        SqlDS.InsertParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);

        SqlDS.Insert();

        this.lbl_thongbao.Text = "Đã thêm mới dữ liệu !!!";
        Load_DSNhaphang();
    }
    protected void imgbtn_sua_Click(object sender, ImageClickEventArgs e)
    {
        SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

        SqlDS.UpdateCommand = "UPDATE NHAP SET MaNCC = @MaNCC, MaNV = @MaNV WHERE MaDNH = @MaDNH";

        SqlDS.UpdateParameters.Add("MaNCC", TypeCode.String, this.txt_mancc.Text);
        SqlDS.UpdateParameters.Add("MaNV", TypeCode.String, this.txt_manv.Text);
        SqlDS.UpdateParameters.Add("MADNH", TypeCode.String, this.txt_madnh.Text);


        SqlDS.Update();

        this.lbl_thongbao.Text = "Đã cập nhật dữ liệu !!!";
        Load_DSNhaphang();
    }
    protected void imgbtn_xoa_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["userLogin1"].ToString() != "QL")
        {
            this.lbl_thongbao.Text = "Bạn không có quyền truy cập vào chức năng này !!!";
        }
        else
        {
            SqlDS.ConnectionString = "Data Source=DESKTOP-GG3O64P\\SQLEXPRESS;Initial Catalog=QUANLY35MM_TEST;Integrated Security=True";

            SqlDS.DeleteCommand = "DELETE FROM NHAP WHERE MaDNH = @MaDNH";

            SqlDS.DeleteParameters.Add("MaDNH", TypeCode.String, this.txt_madnh.Text);

            SqlDS.Delete();

            this.lbl_thongbao.Text = "Đã xóa dữ liệu !!!";

            Load_DSNhaphang();
        }
        
    }
}